from django.contrib import admin
from .models import *

# Register your models here.
@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display=('buyer_id','product_id','seller_id','order_date','quantity','number','address','price')
    search_fields=('id','order_date')
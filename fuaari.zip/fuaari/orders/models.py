from django.db import models
from seller.models import *
from products.models import *
from reviews.models import *

# Create your models here.
class Order(models.Model):
    quantity=models.IntegerField()
    order_date=models.DateTimeField(auto_now_add=True)
    seller_id=models.ForeignKey(Seller,on_delete=models.CASCADE, related_name='seller',default=None)
    buyer_id=models.ForeignKey(User,on_delete=models.CASCADE, related_name='orders')
    product_id=models.ForeignKey(Products,on_delete=models.CASCADE, related_name='order')
    address=models.TextField()
    price=models.ForeignKey(Products,on_delete=models.CASCADE,related_name='orders')
    number=models.CharField(max_length=11,default=None)
    review=models.ForeignKey(Review , on_delete=models.CASCADE,related_name='reviews',null=True, blank=True)

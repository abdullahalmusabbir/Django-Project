from django.urls import path
from . import views

urlpatterns = [
    path('create/<int:product_id>/<int:buyer_id>/<int:seller_id>', views.create_order, name='create_order'),
    path('order_list/',views.order_list,name='order_list'),
    path('delete_order/<int:order_id>',views.delete_order,name='delete_oder'),
]
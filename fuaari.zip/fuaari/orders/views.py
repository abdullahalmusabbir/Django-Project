from django.shortcuts import render, redirect, get_object_or_404
from .forms import OrderForm
from .models import Order
from products.models import Products
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from seller.models import Profile,Seller
from reviews.models import *

# Create your views here.
@login_required
def create_order(request, product_id,buyer_id,seller_id):
    product = get_object_or_404(Products, pk=product_id)
    buyer = get_object_or_404(User, pk=buyer_id)
    seller=get_object_or_404(Seller,pk=seller_id)
    reviews=Review.objects.all()
    
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            order = form.save(commit=False)
            order.product_id = product
            order.buyer_id = buyer
            order.seller_id=seller
            order.price = product  
            order.save()
            profile = request.user.profile
            if product_id not in profile.purchased_products:
                profile.purchased_products.append(product_id)
                profile.save()
            return redirect('product_list')  
    else:
        form = OrderForm()
    
    context = {
        'form': form,
        'product': product,
        'buyer': buyer,
        'reviews':reviews,
    }
    return render(request, 'orders/create_order.html', context)

@login_required
def order_list(request):
    orders=Order.objects.all()
    return render(request, 'orders/order_list.html',{'orders':orders})

def delete_order(request, order_id):
    Order.objects.get(pk=order_id).delete()
    return redirect('order_list')
from django.urls import path
from . import views

urlpatterns = [
    path('signup/',views.sign_up,name='signup'),
    path('login/',views.log_in,name='login'),
    path('signout/',views.sign_out,name='signout'),
    path('deshboard/',views.deshboard,name='deshboard'),
    path('store/',views.store,name='store'),
    path('shop_details/<int:seller_id>/',views.shop_details,name='shop_details'),
]
